#include <iostream>
using namespace std;
class MaxFinder {
public:
    int max(int a, int b) {
        return (a > b) ? a : b;
    }
    double max(double a, double b) {
        return (a > b) ? a : b;
    }
    char max(char a, char b) {
        return (a > b) ? a : b;
    }
};
int main() {
    MaxFinder finder;
    cout << "Max int: " << finder.max(5, 10) <<endl;
    cout << "Max double: " << finder.max(5.5, 10.5) <<endl; 
    cout << "Max char: " << finder.max('a', 'z') <<endl; 
    return 0;
}