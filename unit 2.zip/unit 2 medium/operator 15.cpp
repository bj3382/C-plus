#include <iostream>

class Factorial {
public:
    int factorial(int n) {
        return (n <= 1) ? 1 : n * factorial(n - 1);
    }

    double factorial(double n) {
        if (n < 0) return 0; 
        return (n <= 1) ? 1 : n * factorial(n - 1);
    }
};

int main() {
    Factorial fact;
    std::cout << "Factorial of 5: " << fact.factorial(5) << std::endl;
    std::cout << "Factorial of 5.5: " << fact.factorial(5.5) << std::endl; 
    return 0;
}
