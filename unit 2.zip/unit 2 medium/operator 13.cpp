#include <iostream>
#include <vector>
class Adder {
public:
    std::vector<std::vector<int>> add(const std::vector<std::vector<int>> &a, const std::vector<std::vector<int>> &b) {
        std::vector<std::vector<int>> result(a.size(), std::vector<int>(a[0].size()));
        for (size_t i = 0; i < a.size(); ++i)
            for (size_t j = 0; j < a[i].size(); ++j)
                result[i][j] = a[i][j] + b[i][j];
        return result;
    }
    void add(const int* a, const int* b, int size) {
        std::cout << "Array sum: ";
        for (int i = 0; i < size; ++i) {
            std::cout << (a[i] + b[i]) << " ";
        }
        std::cout << std::endl;
    }
};
int main() {
    Adder adder;
    std::vector<std::vector<int>> m1 = {{1, 2}, {3, 4}};
    std::vector<std::vector<int>> m2 = {{5, 6}, {7, 8}};
    auto result = adder.add(m1, m2);
    std::cout << "Matrix sum:" << std::endl;
    for (const auto &row : result) {
        for (int val : row)
            std::cout << val << " ";
        std::cout << std::endl;
    }
    int a[3] = {1, 2, 3};
    int b[3] = {4, 5, 6};
    adder.add(a, b, 3);
    return 0;
}