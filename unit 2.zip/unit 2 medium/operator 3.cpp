#include <iostream>
using namespace std;
class Point {
public:
    int x, y;
    Point(int x = 0, int y = 0) : x(x), y(y) {}
    friend std::ostream& operator<<(std::ostream &out, const Point &p) {
        out << "(" << p.x << ", " << p.y << ")";
        return out;
    }
};
int main() {
    Point p(3, 4);
    cout << p <<endl;
    return 0;
}