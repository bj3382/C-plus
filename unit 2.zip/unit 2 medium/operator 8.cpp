#include <iostream>
using namespace std;
class Number {
public:
    int value;

    Number(int v = 0) : value(v) {}

    Number operator-(const Number &n) {
        return Number(value - n.value);
    }

    void display() const {
       cout << "Value: " << value <<endl;
    }
};

int main() {
    Number n1(10), n2(5);
    Number n3 = n1 - n2;
    n3.display(); 
    return 0;
}
