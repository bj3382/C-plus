#include <iostream>
using namespace std;
class Array {
public:
    int arr[5];
    Array(int* a) {
        for (int i = 0; i < 5; ++i) {
            arr[i] = a[i];
        }
    }
    int& operator[](int index) {
        return arr[index];
    }
};
int main() {
    int a[5] = {1, 2, 3, 4, 5};
    Array array(a);
    for (int i = 0; i < 5; ++i) {
        cout << array[i] << " "; 
    }
    return 0;
}