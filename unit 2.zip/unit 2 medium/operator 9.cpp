#include <iostream>
using namespace std;

class Adder {
public:
    int add(int a, int b) {
        return a + b;
    }
    double add(double a, double b) {
        return a + b;
    }
};
int main() {
    Adder adder;
    cout << "Integer sum: " << adder.add(5, 10) << endl; 
    cout << "Float sum: " << adder.add(5.5, 10.5) <<endl; 
    return 0;
}
