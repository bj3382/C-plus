#include <iostream>
using namespace std;
class Counter {
public:
    int value;
    Counter(int v = 0) : value(v) {}
    Counter operator++() { 
        ++value;
        return *this;
    }
    void display() const {
        cout << "Value: " << value <<endl;
    }
};
int main() {
    Counter c(5);
    ++c;
    c.display(); 
    return 0;
}