#include <iostream>
class Printer {
public:
    void print(const int* arr, int size) {
        std::cout << "Integer array: ";
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
    void print(const double* arr, int size) {
        std::cout << "Double array: ";
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
    void print(const char* arr, int size) {
        std::cout << "Character array: ";
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
};
int main() {
    Printer printer;
    int intArr[3] = {1, 2, 3};
    double doubleArr[3] = {1.1, 2.2, 3.3};
    char charArr[3] = {'a', 'b', 'c'};
    printer.print(intArr, 3);
    printer.print(doubleArr, 3);
    printer.print(charArr, 3);
    return 0;
}