#include<iostream>
using namespace std;
int main(){
	int num,sum=0,i=1;
	cout<<"enter the number";
	cin>>num;
	if(num<0){
		cout<<"enter positive integer:";
		
	}else{
		while(i<=num/2){
			if(num%i==0){
				sum+=i;
			}
			i++;
		}
		if(num==sum)
		{
			cout<<"is perfect";
		}else{
			cout<<"is not perfect";
		}
	}
}