#include <iostream>
#include <algorithm>
class Sorter {
public:
    void sort(int* arr, int size) {
        std::sort(arr, arr + size);
        std::cout << "Sorted Integer array: ";
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
    void sort(double* arr, int size) {
        std::sort(arr, arr + size);
        std::cout << "Sorted Double array: ";
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
};
int main() {
    Sorter sorter;
    int intArr[5] = {5, 3, 1, 4, 2};
    double doubleArr[5] = {5.5, 3.3, 1.1, 4.4, 2.2};
    sorter.sort(intArr, 5);
    sorter.sort(doubleArr, 5);
    return 0;
}