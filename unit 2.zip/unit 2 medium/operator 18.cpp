#include <iostream>
#include <cmath>

class AbsoluteValue {
public:
    int abs(int n) {
        return (n < 0) ? -n : n;
    }

    double abs(double n) {
        return std::fabs(n);
    }
};

int main() {
    AbsoluteValue av;
    std::cout << "Absolute value of -10: " << av.abs(-10) << std::endl; 
    std::cout << "Absolute value of -10.5: " << av.abs(-10.5) << std::endl; 
    return 0;
}
