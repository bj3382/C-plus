#include <iostream>
using namespace std;
class Box {
public:
    int length;
    Box(int l = 0) : length(l) {}
    bool operator==(const Box &b) {
        return length == b.length;
    }
};
int main() {
    Box b1(5), b2(5);
    if (b1 == b2) {
        cout << "Boxes are equal." <<endl;
    }
    return 0;
}