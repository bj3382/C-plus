#include <iostream>
#include <cmath>

class PowerCalculator {
public:
    double power(int base, int exponent) {
        return std::pow(base, exponent);
    }

    double power(double base, double exponent) {
        return std::pow(base, exponent);
    }
};

int main() {
    PowerCalculator pc;
    std::cout << "2^3 = " << pc.power(2, 3) << std::endl; 
    std::cout << "2.5^2.0 = " << pc.power(2.5, 2.0) << std::endl; 
    return 0;
}
