#include <iostream>
using namespace std;
class Functor {
public:
    void operator()(int a, int b) {
        std::cout << "Sum: " << (a + b) << std::endl;
    }
};
int main() {
    Functor f;
    f(3, 4);
    return 0;
}