#include <iostream>
#include <string.h>
class Concatenator {
public:
    void concatenate(const char* a, const char* b) {
        char result[100];
        strcpy(result, a);
        strcat(result, b);
        std::cout << "Concatenated C-strings: " << result << std::endl;
    }

    void concatenate(const std::string &a, const std::string &b) {
        std::cout << "Concatenated strings: " << a + b << std::endl;
    }
};

int main() {
    Concatenator concat;
    const char* str1 = "Hello, ";
    const char* str2 = "World!";
    concat.concatenate(str1, str2); 
    concat.concatenate(std::string("Goodbye, "), std::string("World!")); 
    return 0;
}
