#include <iostream>
#include<cmath>
using namespace std;

int main() {
    float num1, num2;

    cin >> num1 >> num2;
    
    cout << "Addition: " << num1 + num2 << "\nSubtraction: " << num1 - num2 
         << "\nMultiplication: " << num1 * num2;

    if (num2 != 0) 
        cout << "\nDivision: " << num1 / num2 << "\nModulo: " << fmod(num1 , num2);
    else 
        cout << "\nDivision and modulo by zero are not allowed.";

    return 0;
}
