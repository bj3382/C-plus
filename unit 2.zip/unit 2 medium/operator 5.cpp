#include <iostream>
#include <vector>
using namespace std;
class Matrix {
public:
    std::vector<std::vector<int>> mat;
    int rows, cols;
    Matrix(int r, int c) : rows(r), cols(c) {
        mat.resize(r, std::vector<int>(c));
    }
    void input() {
        for (int i = 0; i < rows; ++i)
            for (int j = 0; j < cols; ++j)
                std::cin >> mat[i][j];
    }
    Matrix operator*(const Matrix &m) {
        Matrix result(rows, m.cols);
        for (int i = 0; i < rows; ++i)
            for (int j = 0; j < m.cols; ++j)
                for (int k = 0; k < cols; ++k)
                    result.mat[i][j] += mat[i][k] * m.mat[k][j];
        return result;
    }
    void display() const {
        for (const auto &row : mat) {
            for (int val : row)
                std::cout << val << " ";
            std::cout << std::endl;
        }
    }
};
int main() {
    Matrix m1(2, 2);
    Matrix m2(2, 2);
    std::cout << "Enter elements of Matrix 1 (2x2):" << std::endl;
    m1.input();
    std::cout << "Enter elements of Matrix 2 (2x2):" << std::endl;
    m2.input();
    Matrix m3 = m1 * m2;
    std::cout << "Result of multiplication:" << std::endl;
    m3.display();
    return 0;
}