#include<iostream>
using namespace std;
int main(){
	int p,t,r,i;
	cout<<"enter principle:";
	cin>>p;
	cout<<"enter rate:";
	cin>>r;
	cout<<"enter time(in years):";
	cin>>t;
	
	i=p*t*r/100;
	cout<<"simple intrest:"<<i;
	
}