#include<iostream>
#include<string>
using namespace std;
int main(){
	string username1,username2;
	cout<<"enter the username: ";
	getline(cin,username1);
	cout<<"re enter the username: ";
	getline(cin,username2);
	if(username1==username2){
		cout<<"valid";
	}else{
		cout<<"ivalid";
	}
}