#include <iostream>
#include <string>
using namespace std;

bool isPalindrome(const string& str) {
    for (int i = 0, j = str.length() - 1; i < j; ++i, --j) {
        if (str[i] != str[j]) return false; // If characters do not match
    }
    return true; // All characters match
}

int main() {
    string input;
    cout << "Enter the string: ";
    getline(cin, input); // Read the entire line
    cout << (isPalindrome(input) ? "PALINDROME" : "NOT PALINDROME") << endl; // Output result
    return 0;
}
