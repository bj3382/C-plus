#include <iostream>
using namespace std;

int getPerson() {
    int age;
    cout << "Enter your age: ";
    cin >> age;
    return (age >= 0) ? age : -1;
}

void checkEligibility(int age) {
    if (age >= 18)
        cout << "You are eligible to vote." << endl;
    else
        cout << "You are allowed to vote after " << 18 - age << " years." << endl;
}

int main() {
    int age = getPerson();
    if (age != -1)
        checkEligibility(age);
    else
        cout << "Invalid input." << endl;

    return 0;
}
