#include<iostream>
using namespace std;
	int calculatesum(int a=0,int b=0,int c=0,int d=0){
		return a+b+c+d;
	}
	int main(){
		int n1,n2,n3,n4;
		cout<<"enter the numbers";
		cin>>n1>>n2>>n3>>n4;
		int total=calculatesum(n1,n2,n3,n4);
		cout<<"th total is"<<total;
	}
	
	