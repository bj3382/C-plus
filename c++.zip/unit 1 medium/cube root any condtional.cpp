#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double num;
    cout << "Input a number: ";
    cin >> num;

    if (cin.fail()) {
        cout << "Invalid input." << endl;
    } else {
        cout << "Cube root of " << num << " is: " << cbrt(num) << endl;
    }

    return 0;
}
