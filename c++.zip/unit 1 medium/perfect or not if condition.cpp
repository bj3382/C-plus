#include <iostream>
using namespace std;

int main() {
    int num, sum = 0;
    cout << "Enter a number: ";
    cin >> num;

    if (cin && num > 0) {
        for (int i = 1; i <= num / 2; i++)
            sum += (num % i == 0) ? i : 0;
        cout << (sum == num ? "Perfect number." : "Not a perfect number.") << endl;
    } else {
        cout << "Invalid input." << endl;
    }
    return 0;
}
