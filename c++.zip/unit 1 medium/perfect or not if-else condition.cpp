#include <iostream>
using namespace std;

int main() {
    int num, sum = 0;
    cout << "Enter a number: ";
    cin >> num;

    if (num > 0 && cin) {
        for (int i = 1; i <= num / 2; i++)
            if (num % i == 0) sum += i;
            
        cout << (sum == num ? to_string(num) + " is a perfect number." : to_string(num) + " is not a perfect number.") << endl;
    } else {
        cout << "Invalid input." << endl;
    }

    return 0;
}
