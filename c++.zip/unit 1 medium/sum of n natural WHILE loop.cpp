#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;

    cout << "Enter the value of n: ";
    cin >> n;

    if (n < 0) return cout << "Invalid input. Please enter a non-negative integer." << endl, 1;

    cout << "Enter the numbers: ";
    while (n--) {
        int number;
        cin >> number;
        sum += number;
    }

    cout << "Sum: " << sum << endl;
    return 0;
}
