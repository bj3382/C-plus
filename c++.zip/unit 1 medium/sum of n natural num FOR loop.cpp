#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;

    cout << "Enter the value of n: ";
    cin >> n;

    if (n < 0) {
        cout << "Invalid input. Please enter a non-negative integer." << endl;
        return 1;
    }

    cout << "Enter the numbers: ";
    for (int i = 0, number; i < n; sum += number, i++) {
        cin >> number;
    }

    cout << "Sum: " << sum << endl;
    return 0;
}
