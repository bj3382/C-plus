#include <iostream>
using namespace std;

int main() {
    int number, sum = 0, i = 1;

    cout << "Enter a positive integer: ";
    cin >> number;

    if (number < 1) return cout << "Invalid input." << endl, 1;

    while (i <= number / 2) {
        if (number % i++ == 0) sum += i - 1; // Add divisor to sum
    }

    cout << number << (sum == number ? " is a perfect number." : " is not a perfect number.") << endl;

    return 0;
}
