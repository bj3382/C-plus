#include <iostream>
using namespace std;

int main() {
    double num;
    cout << "Input a number: ";
    cin >> num;

    if (cin.fail() || num < 0) {
        cout << "Invalid input or square root not defined for negative numbers." << endl;
    } else {
        double sqrtVal = 0;
        for (double i = 0; i <= num; i += 0.01) {
            if (i * i >= num) {
                sqrtVal = i;
                break;
            }
        }
        cout << "Approximate square root: " << sqrtVal << endl;
    }
    return 0;
}
