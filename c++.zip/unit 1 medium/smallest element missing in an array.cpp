#include <iostream>
#include <vector>
using namespace std;

int findMissing(const vector<int>& arr) {
    int expected = 0, i = 0;
    while (i < arr.size()) {
        if (arr[i] == expected) expected++;
        i++;
    }
    return expected;
}

int main() {
    vector<int> arr = {0, 1, 2, 3, 5, 6, 7}; 
    cout << "The smallest missing element is: " << findMissing(arr) << endl;
    return 0;
}
