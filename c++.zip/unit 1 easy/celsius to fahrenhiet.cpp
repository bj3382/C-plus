#include <iostream>
using namespace std;

int main() {
    double celsius;
    cout << "Enter temperature in Celsius: ";
    cin >> celsius;

    if (cin.fail())
        cout << "Invalid input." << endl;
    else
        cout << "Temperature in Fahrenheit: " << (celsius * 9 / 5) + 32 << endl;

    return 0;
}
