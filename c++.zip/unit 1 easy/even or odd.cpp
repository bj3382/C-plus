#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (cin.fail()) 
        cout << "Invalid input." << endl;
    else
        cout << (num % 2 == 0 ? "Even" : "Odd") << endl;

    return 0;
}
