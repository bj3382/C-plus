#include<iostream>
using namespace std;
int main(){
	int n,rem,rev=0;
	cout<<"enter a number:";
	cin>>n;
	
	int orginalnum=n;
	while(n!=0){
		rem=n%10;
		rev=rev*10+rem;
		n=n/10;
	}
	if(orginalnum==rev){
		cout<<orginalnum<<" is palindrome";
		
	}
	else{
		cout<<orginalnum<<" is not palindrome";
	}
}