#include <iostream>
#include <algorithm> 
using namespace std;

int main() {
    string str;
    cout << "Enter the string: ";
    getline(cin, str);

    string upperStr = str;
    transform(upperStr.begin(), upperStr.end(), upperStr.begin(), ::toupper);
    cout << "Uppercase: " << upperStr << endl;

    string lowerStr = str;
    transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), ::tolower);
    cout << "Lowercase: " << lowerStr << endl;

    return 0;
}
