#include <iostream>
#include <unordered_map>
using namespace std;

int main() {
    int size;
    cout << "Enter size of the array: ";
    cin >> size;

    unordered_map<int, int> frequencyMap;
    int mostFrequent, maxCount = 0;

    // Input elements and count frequencies
    for (int i = 0; i < size; i++) {
        int element;
        cout << "Enter Element " << (i + 1) << ": ";
        cin >> element;
        frequencyMap[element]++;
        
        // Update most frequent element
        if (frequencyMap[element] > maxCount) {
            maxCount = frequencyMap[element];
            mostFrequent = element;
        }
    }

    cout << "Most occurred number: " << mostFrequent << endl;
    return 0;
}