#include <iostream>
using namespace std;

int fibonacci(int n) {
    if (n < 0) return -1; 
    if (n == 0) return 0;
    if (n == 1) return 1;

    int a = 0, b = 1;
    for (int i = 2; i <= n; i++) {
        int c = a + b; 
        a = b;        
        b = c;
    }
    return b; 
}

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    cin >> n;

    if (cin.fail() || n < 0) {
        cout << "Invalid input. Please enter a non-negative integer." << endl;
        return 1; // Exit with error code
    }

    int result = fibonacci(n);
    cout << "The " << n << "th Fibonacci number is: " << result << endl;
    
    return 0;
}