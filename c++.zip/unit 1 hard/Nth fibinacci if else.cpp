#include<iostream>
using namespace std;
int main(){
	int n;
	cout<<"enter the number";
	cin>>n;
	int a=0,b=1,fibo;
	if(n==1){
		cout<<"nth fibo"<<a;
	}else
	if(n==2){
		cout<<"nth fibo"<<b;
	}else
	for(int i=2;i<=n;i++){
		fibo=a+b;
		a=b;
		b=fibo;
	}
	cout<<"nth fibo is"<<b;
}